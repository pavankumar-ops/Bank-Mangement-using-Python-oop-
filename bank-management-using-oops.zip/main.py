#Bank operation using OOP

class Bank:
    bankname = "Hamari apni Bank"
    branch = "Pune, Maharashtra, India"
    
    def __init__(self, username, mobileno, address):
        self.username = username
        self.mobileno = mobileno
        self.address = address
        self.balance=0.0
        print(f"Hello {self.username}, congratulations! Account created successfully.")
        print(f'Welcome to{Bank.bankname},{Bank.branch}')
        
        #Deposit
    def Deposit(self,amount):
        self.balance=self.balance+amount #Self balance is 0.0
        print(f'{amount},Deposited successfully')
       
       #Withdraw
    def Withdraw(self,amount) :
        if amount<self.balance:
         self.balance=self.balance-amount
         print(f'{amount}Withdraw successfully')
        else:
            print('Insuffcient Fund........')
            
        #MiniStatment
    def MiniStatment(self): 
        print(f'Your account balance is {self.balance}')
        
        
# Getting user input and creating an account
username = input("Enter a name: ")
mobileno = input("Enter Mobile no: ")
address = input("Enter address: ")



b = Bank(username, mobileno, address) #object creation based on user provided data


while True:
  print('please select any option')
  print('1.Deposit\n 2.Withdraw\n 3.MiniStatment\n 4.Stop')
  option=int(input(''))
  
  if option==1:
      amount=float(input('Enter Deposit amount'))
      b.Deposit(amount)
  elif option==2:
      amount=float(input('Enter Withdraw amount'))
      b.Withdraw(amount)
      
  elif option==3:
      b.MiniStatment()
      
      
  elif option==4:
      print("Thanks for using Hamri apni Bank.........")
      break
  else:
      print("Invalid option,please try again.")
# Display the account information
print(f"Account Holder: {b.username}")
print(f"Mobile Number: {b.mobileno}")
print(f"Address: {b.address}")

